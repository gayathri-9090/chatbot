from fastapi import FastAPI, Request, File, UploadFile, HTTPException, Form, Response, Depends
from fastapi.responses import HTMLResponse, PlainTextResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List
from starlette.status import HTTP_200_OK
import random
import json
import os
import re
import requests
from difflib import SequenceMatcher
from twilio.rest import Client

app = FastAPI()

templates = Jinja2Templates(directory="templates")

GREET_INPUTS = ("hello", "hi", "greetings", "sup", "what's up", "hey")
GREET_RESPONSES = ["hi", "hey", "*nods*", "hi there", "hello", "I am glad! You are talking to me"]
EXIT_RESPONSES = ["Bye", "See you later!", "Good bye!", "Hope to see you again"]

feedback_file_path = "supervised_learning.txt"
CONVERSATION_FILE_PATH = "conversations.json"

with open("dataset.json", "r") as file:
    dataset = json.load(file)

def greet(sentence):
    for word in sentence.split():
        if word.lower() in GREET_INPUTS:
            return random.choice(GREET_RESPONSES)

def load_conversations():
    with open(CONVERSATION_FILE_PATH, "r") as conversation_file:
        return json.load(conversation_file)["conversations"]

def give_best_match(user_input, options):
    max_ratio = 0
    best_match = None

    for option in options:
        ratio = fuzz.ratio(user_input, option.lower())
        if ratio > max_ratio:
            max_ratio = ratio
            best_match = option

    return best_match

def process_feedback_lines(user_input,supervised_learning, threshold):
    user_messages = []
    bot_responses = []

    for line in supervised_learning:
        line = line.strip()
        if line.startswith("User Message:"):
            user_messages.append(line.replace("User Message:", "").strip())
        elif line.startswith("Bot Response:"):
            bot_responses.append(line.replace("Bot Response:", "").strip())

    for user_msg, stored_bot_response in zip(user_messages, bot_responses):
        similarity_ratio = SequenceMatcher(None, user_input, user_msg.lower()).ratio()
        if similarity_ratio >= threshold:
            if stored_bot_response[-1] in ["!", "."]:
                if "<a></a>" in stored_bot_response:
                    return stored_bot_response
                elif "/" in stored_bot_response:
                    stored_bot_response = stored_bot_response.replace("/", "<br>\u2022")
                return stored_bot_response
            else:
                formatted_response = stored_bot_response
                if "<a></a>" in formatted_response:
                    return formatted_response
                elif "/" in formatted_response:
                    formatted_response = formatted_response.replace("/", "<br>\u2022")
                return formatted_response + "."
    return None

def random_string():
    random_list = [
        "Please try writing something more descriptive.",
        "Oh! It appears you wrote something I don't understand yet",
        "Do you mind trying to rephrase that?",
        "I'm terribly sorry, I didn't quite catch that.",
        "I can't answer that yet, please try asking something else."
    ]

    list_count = len(random_list)
    random_item = random.randrange(list_count)

    return random_list[random_item]

def generate_response(user_input):
    global dataset, no_counter
    print(f"Received user input: {user_input}")

    if user_input.lower() in GREET_INPUTS:
        return greet(user_input) + "."

    if user_input.lower() in ["bye", "see you later"]:
        return random.choice(EXIT_RESPONSES)

    SIMILARITY_THRESHOLDS = [1.0, 0.9, 0.8]

    with open(feedback_file_path, "r") as feedback_file:
        feedback_lines = feedback_file.readlines()
        for threshold in SIMILARITY_THRESHOLDS:
            result = process_feedback_lines(user_input.lower(),feedback_lines, threshold)
            if result:
                return result

    user_queries_to_bot_responses = {}

    for sub_topic, sub_data in dataset["software"].items():
        user_queries = sub_data.get("user_queries", [])
        bot_responses = sub_data.get("bot_responses", [])

        key_value_pairs = dict(zip(user_queries, bot_responses))
        user_queries_to_bot_responses.update(key_value_pairs)
        
    for sub_topic, sub_data in dataset["java"].items():
        user_queries = sub_data.get("user_queries", [])
        bot_responses = sub_data.get("bot_responses", [])

        key_value_pairs = dict(zip(user_queries, bot_responses))
        user_queries_to_bot_responses.update(key_value_pairs)    

    def get_best_match(query, query_dict, threshold=0.85):
        best_match = None
        best_ratio = 0

        for stored_query in query_dict:
            ratio = SequenceMatcher(None, query.lower(), stored_query.lower()).ratio()
            if ratio > best_ratio and ratio >= threshold:
                best_ratio = ratio
                best_match = stored_query
        return best_match

    current_data = dataset
    keywords = user_input.lower().split()
    for keyword in keywords:
        options = [key for key in current_data.keys() if fuzz.partial_ratio(keyword, key) > 90]
        if not options:
            continue
        best_match = give_best_match(keyword, options)
        current_data = current_data[best_match]
    if "bot_responses" in current_data:
        return random.choice(current_data["bot_responses"])

    for subroot in dataset:
        subroot_data = dataset[subroot]
        current_data = subroot_data

        keywords = user_input.lower().split()
        for keyword in keywords:
            if keyword in current_data:
                current_data = current_data[keyword]

        if "bot_responses" in current_data:
            return random.choice(current_data["bot_responses"])

    best_match = get_best_match(user_input, user_queries_to_bot_responses)
    if best_match and best_match in user_queries_to_bot_responses:
        return user_queries_to_bot_responses[best_match]

    conversations = load_conversations()

    for entry in conversations:
        pattern = entry['user_input']
        if re.match(pattern, user_input, re.IGNORECASE):
            # Reset the counter after providing a response
            no_counter = 0
            if '{user_input}' in entry.get('bot_response', ''):
                return entry['bot_response'].replace('{user_input}', user_input)
            else:
                return entry.get('bot_response', '')

    if user_input.lower() in ["what is java","what is java?","define java"] or user_input.lower() == "java":
        return "Java is a versatile, object-oriented programming language developed by Sun Microsystems (now owned by Oracle). It is known for its platform independence, meaning that Java programs can run on various devices without modification. Java is widely used for developing web applications, mobile applications (Android), enterprise software, and more, thanks to its portability and robustness."

    elif user_input.lower() in ["what is software","what is software?","define software"] or user_input.lower() == "software":
        return "Software refers to a set of instructions or programs that enable a computer or other hardware to perform specific tasks. It encompasses a wide range of applications, operating systems, utilities, and other programs that help users interact with and make the most of their computer systems. Software can be categorized into two main types: system software, which manages and controls computer hardware, and application software, which provides functionality for specific tasks or activities, such as word processing, gaming, or web browsing."

    return random_string()
    
@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/tutorial")
def tutorial(request: Request):
    return templates.TemplateResponse("tutorial.html", {"request": request})

@app.get("/bot")
def bot(request: Request):
    return templates.TemplateResponse("chatbot.html", {"request": request})

@app.get("/details")
def details(request: Request):
    return templates.TemplateResponse("about.html", {"request": request})

@app.get("/login")
def login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/history")
def history(request: Request):
    return templates.TemplateResponse("history.html", {"request": request})

@app.get("/logout")
def logout(request: Request):
    return templates.TemplateResponse("logout.html", {"request": request})

account_sid = 'ACa3d48f183edb1fcf3f0f9ab3f6b94c83'
auth_token = '4bab091ad18fde1781d626e4b74500a2'
twilio_phone_number = '+12253417132'
your_phone_number = '+919908065462'

client = Client(account_sid, auth_token)

@app.post("/submit_form")
async def submit_form(request: Request):
    try:
        form_data = await request.form()
        name = form_data.get('name')
        email = form_data.get('email')
        message = form_data.get('message')

        if name and email and message:
            with open("form_data.txt", "a", encoding="utf-8") as file:
                file.write(f"Name: {name}\nEmail: {email}\nMessage: {message}\n\n")

            # Send SMS using Twilio
            message_body = f'New Form Submission from {name}. \nEmail: {email} \nMessage: {message}'
            client.messages.create(
                body=message_body,
                from_=twilio_phone_number,
                to=your_phone_number
            )

            return Response("Data submitted successfully! We will respond soon.")

        return Response("Data submission failed.")

    except Exception as e:
        return Response(f"Internal Server Error. {e}")

@app.post("/send_message")
async def send_message(request: Request):
    user_message = (await request.form()).get('user_message')

    if user_message.lower().startswith("feedback:"):
        feedback = user_message[len("feedback:"):].strip()
        if feedback:
            with open("drawbacks.txt", "a", encoding="utf-8") as drawbacks_file:
                drawbacks_file.write(feedback + "\n")
            return JSONResponse(content={"bot_response": "Thank you for your feedback."})

    if user_message.lower() in ['thanks', 'thank you']:
        bot_response = "You are welcome."
    else:
        bot_response = generate_response(user_message)

    global um
    um = user_message

    return JSONResponse(content={"bot_response": bot_response})

@app.post("/signup")
async def signup(request: Request):
    data = await request.json()
    username = data.get('username')
    password = data.get('password')
    secret_key = data.get('password')

    if username and password:
        user_data = f"Username: {username}, Password: {password}, Secret Key: {secret_key}"
        file_path = os.path.join(data_directory, f"{username}.txt")
        with open(file_path, "w", encoding="utf-8") as user_file:
            user_file.write(user_data)

        return JSONResponse(content={"message": "Registration successful"})
    else:
        return JSONResponse(content={"message": "Invalid input"}, status_code=400)

@app.get("/check_user")
async def check_user(username: str):
    if username:
        file_path = os.path.join(data_directory, f"{username}.txt")
        user_exists = os.path.exists(file_path)
        return JSONResponse(content={"exists": user_exists})
    else:
        return JSONResponse(content={"exists": False})

@app.post("/create_user")
async def create_user(request: Request):
    data = await request.json()
    username = data.get('username')
    password = data.get('password')
    secret_key = data.get('secretKey')

    if username and password and secret_key:
        # Store user data in a text file
        user_data = f"Username: {username}, Password: {password}, Secret Key: {secret_key}"
        file_path = os.path.join(data_directory, f"{username}.txt")
        with open(file_path, "w", encoding="utf-8") as user_file:
            user_file.write(user_data)

        return JSONResponse(content={"message": "User creation successful"})
    else:
        return JSONResponse(content={"message": "Invalid input"}, status_code=400)

@app.post("/loginuser")
async def loginuser(request: Request):
    data = await request.json()
    username = data.get('username')
    password = data.get('password')

    if username and password:
        file_path = os.path.join(data_directory, f"{username}.txt")
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as user_file:
                user_data = user_file.read()
                if f"Username: {username}, Password: {password}" in user_data:
                    return JSONResponse(content={"message": "Login successful"})

        return JSONResponse(content={"message": "Invalid login credentials"}, status_code=401)
    else:
        return JSONResponse(content={"message": "Invalid input"}, status_code=400)

@app.post("/reset_password")
async def reset_password(request: Request):
    data = await request.json()
    username = data.get('username')
    secret_key = data.get('secret_key')
    new_password = data.get('new_password')
    confirm_password = data.get('confirm_password')

    if (
        username == "" or
        secret_key == "" or
        new_password == "" or
        confirm_password == ""
    ):
        return JSONResponse(content={"message": "Please fill all fields!"}, status_code=400)

    if username and secret_key and new_password and confirm_password:
        file_path = os.path.join(data_directory, f"{username}.txt")
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as user_file:
                user_data = user_file.read()
                stored_secret_key = re.search(r'Secret Key: (\w+)', user_data).group(1)

                if secret_key == stored_secret_key:
                    if new_password == confirm_password:
                        user_data = re.sub(r'Password: (\w+)', f'Password: {new_password}', user_data)
                        with open(file_path, "w", encoding="utf-8") as updated_file:
                            updated_file.write(user_data)
                        return JSONResponse(content={"message": "Password reset successful"})
                    else:
                        return JSONResponse(content={"message": "Passwords do not match"}, status_code=400)
                else:
                    return JSONResponse(content={"message": "Invalid secret key"}, status_code=400)

        return JSONResponse(content={"message": "Invalid credentials for password reset"}, status_code=400)
    else:
        return JSONResponse(content={"message": "Invalid input"}, status_code=400)

@app.get("/get_secret_key")
async def get_secret_key(username: str):
    if username:
        file_path = os.path.join(data_directory, f"{username}.txt")
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as user_file:
                user_data = user_file.read()
                stored_secret_key = re.search(r'Secret Key: (\w+)', user_data).group(1)
                return JSONResponse(content={"secretKey": stored_secret_key})

    return JSONResponse(content={"secretKey": None})

@app.post("/provide_feedback")
async def provide_feedback(request: Request):
    form_data = await request.form()
    bot_response = form_data.get('bot_response')
    feedback = form_data.get('feedback')
    if not feedback:
        return PlainTextResponse("Please provide feedback for the bot's response.", status_code=400)

    # Save feedback to a text file
    with open(feedback_file_path, "a", encoding="utf-8") as feedback_file:
        feedback_file.write(f"User Message: {um}\n")
        feedback_file.write(f"Bot Response: {bot_response}\n")
        feedback_file.write(f"Feedback: {feedback}\n\n")

    return PlainTextResponse("Feedback received successfully.")

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)